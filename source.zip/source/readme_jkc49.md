jkc49

I helped in implementeing the baseline model and gru model. Later, i performed experimentations which brought the accuracy score closer to the one obtained in paper as we during milestone were having trouble obtaining accuracy equivalent to one stated in paper.

I performed the documentation on jupyter notebook.

Instructions to run the project are listed in readme_project_instructions.md