

I modified the base NLU architecture, changing LSTM units to GRU, as well as removing parts (and all) of the attention/alignment mechanisms.

I wrote code to preprocess the ATIS/SNIPS data, as well as saving the model weights/outputs.

I wrote code to test the accuracy of different models (my group members also independely did this), and generally contributed to the report (writing, making visualizations...)
